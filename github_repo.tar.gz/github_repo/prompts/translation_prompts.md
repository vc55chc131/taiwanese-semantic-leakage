# GPT-4O Prompt Templates for Taiwanese Translation

## Translation Prompt Template
```
You are a professional translator with expertise in Taiwanese (Hokkien/臺語/台語) and Mandarin Chinese. 
Please translate the following Taiwanese text to Mandarin Chinese.
Maintain the original meaning, tone, and cultural nuances as much as possible.
If there are specific Taiwanese expressions that don't have direct Mandarin equivalents, 
provide the closest natural expression in Mandarin.

Text to translate:
{input_text}
```

## Back-translation Prompt Template
```
You are a professional translator with expertise in Mandarin Chinese and Taiwanese (Hokkien/臺語/台語).
Please translate the following Mandarin Chinese text to Taiwanese (Hokkien).
Use Taiwanese romanization (Pe̍h-ōe-jī/POJ) alongside Chinese characters where appropriate.
Maintain the original meaning, tone, and cultural nuances as much as possible.
If there are specific Mandarin expressions that don't have direct Taiwanese equivalents,
provide the closest natural expression in Taiwanese.

Text to translate:
{input_text}
```

## Semantic Leakage Analysis Prompt Template
```
You are a computational linguist specializing in translation analysis between Taiwanese (Hokkien/臺語/台語) and Mandarin Chinese.
Analyze the following original Taiwanese text, its Mandarin translation, and the back-translation to Taiwanese.
Identify any semantic leakage, where meaning, nuance, or cultural elements are lost or altered in the translation process.

Original Taiwanese:
{original_text}

Mandarin Translation:
{translation_text}

Back-translation to Taiwanese:
{back_translation_text}

Please provide:
1. A semantic leakage index (SLI) from 0.0 to 1.0, where 0.0 means perfect preservation of meaning and 1.0 means complete loss
2. Specific linguistic features that were lost or altered
3. Brief explanation of cultural or pragmatic elements that didn't transfer well
```

## API Parameters
```json
{
  "model": "gpt-4o",
  "temperature": 0.3,
  "top_p": 0.95,
  "max_tokens": 1000,
  "frequency_penalty": 0.0,
  "presence_penalty": 0.0
}
```
