# Benchmark Test Sets for Taiwanese-Mandarin Translation

## Test Set 1: General Domain (200 sentences)
This test set contains 200 randomly selected sentences from the general corpus, covering everyday conversations, common expressions, and general topics.

## Test Set 2: Technical Domain (100 sentences)
This test set contains 100 sentences from technical and specialized domains, including medical, legal, and technical terminology.

## Test Set 3: Colloquial Speech (150 sentences)
This test set contains 150 sentences of highly colloquial Taiwanese speech, with extensive use of particles, reduplications, and other features characteristic of spoken Taiwanese.

## Benchmark Results

### GPT-4O Performance

| Test Set | BLEU Score | BERTScore | Human Adequacy (1-5) | Human Fluency (1-5) | SLI (avg) |
|----------|------------|-----------|----------------------|---------------------|-----------|
| General Domain | 31.2 | 0.76 | 3.8 | 4.2 | 0.14 |
| Technical Domain | 24.5 | 0.68 | 3.2 | 3.9 | 0.21 |
| Colloquial Speech | 27.8 | 0.72 | 3.5 | 4.0 | 0.12 |

### Comparison with Specialized Systems

| System | BLEU Score (avg) | BERTScore (avg) | Human Adequacy (avg) | Human Fluency (avg) | SLI (avg) |
|--------|-----------------|----------------|---------------------|-------------------|----------|
| GPT-4O | 28.5 | 0.72 | 3.5 | 4.0 | 0.16 |
| Specialized NMT | 38.7 | 0.82 | 4.3 | 4.5 | 0.09 |
| Human Translators | 42.3 | 0.87 | 4.7 | 4.8 | 0.05 |

### Performance by Linguistic Feature

| Feature | GPT-4O SLI | Human SLI | Error Rate Difference |
|---------|------------|-----------|----------------------|
| Aspect Markers | 0.24 | 0.08 | +200% |
| Sentence-Final Particles | 0.31 | 0.11 | +182% |
| Reduplication | 0.19 | 0.09 | +111% |
| Kinship Terms | 0.15 | 0.04 | +275% |
| Directional Compounds | 0.22 | 0.07 | +214% |
