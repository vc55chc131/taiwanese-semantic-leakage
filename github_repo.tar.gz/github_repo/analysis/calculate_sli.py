"""
Calculate Semantic Leakage Index (SLI) for Taiwanese-Mandarin translations

This script calculates the Semantic Leakage Index (SLI) for translations between
Taiwanese and Mandarin Chinese, using embedding distances and entropy measures.

Usage:
    python calculate_sli.py --input <input_file> --output <output_file>

Author: Research Team
Date: May 2024
"""

import pandas as pd
import numpy as np
from scipy.stats import entropy
import jieba
from sklearn.feature_extraction.text import CountVectorizer
from sentence_transformers import SentenceTransformer
from scipy.spatial.distance import cosine
import argparse
import os
import json
import matplotlib.pyplot as plt
import seaborn as sns

# Load custom dictionary for Taiwanese segmentation
def load_custom_dict(dict_path):
    """Load custom Taiwanese dictionary for Jieba"""
    print(f"Loading custom dictionary from {dict_path}")
    jieba.load_userdict(dict_path)
    print("Custom dictionary loaded")

# Calculate Type-Token Ratio (TTR) for text
def calculate_ttr(text):
    """Calculate Type-Token Ratio for given text"""
    if not text:
        return 0.0
    
    # Segment text using Jieba
    words = list(jieba.cut(text))
    
    # Calculate TTR
    types = len(set(words))
    tokens = len(words)
    
    if tokens == 0:
        return 0.0
    
    return types / tokens

# Calculate entropy of text
def calculate_entropy(text):
    """Calculate entropy of character distribution in text"""
    if not text:
        return 0.0
    
    # Count character frequencies
    char_counts = {}
    for char in text:
        if char in char_counts:
            char_counts[char] += 1
        else:
            char_counts[char] = 1
    
    # Calculate probabilities
    total_chars = len(text)
    probs = [count / total_chars for count in char_counts.values()]
    
    # Calculate entropy
    return entropy(probs, base=2)

# Calculate embedding distance between texts
def calculate_embedding_distance(text1, text2, model):
    """Calculate cosine distance between sentence embeddings"""
    if not text1 or not text2:
        return 1.0  # Maximum distance
    
    # Get embeddings
    embedding1 = model.encode(text1)
    embedding2 = model.encode(text2)
    
    # Calculate cosine distance
    return cosine(embedding1, embedding2)

# Calculate Semantic Leakage Index (SLI)
def calculate_sli(original, translation, back_translation, model):
    """Calculate Semantic Leakage Index (SLI)"""
    # Calculate entropy measures
    original_entropy = calculate_entropy(original)
    back_translation_entropy = calculate_entropy(back_translation)
    entropy_reduction = max(0, (original_entropy - back_translation_entropy) / original_entropy) if original_entropy > 0 else 0
    
    # Calculate TTR measures
    original_ttr = calculate_ttr(original)
    back_translation_ttr = calculate_ttr(back_translation)
    ttr_reduction = max(0, (original_ttr - back_translation_ttr) / original_ttr) if original_ttr > 0 else 0
    
    # Calculate embedding distance
    embedding_distance = calculate_embedding_distance(original, back_translation, model)
    
    # Calculate SLI as weighted combination
    weights = {
        'entropy_reduction': 0.3,
        'ttr_reduction': 0.3,
        'embedding_distance': 0.4
    }
    
    sli = (
        weights['entropy_reduction'] * entropy_reduction +
        weights['ttr_reduction'] * ttr_reduction +
        weights['embedding_distance'] * embedding_distance
    )
    
    return {
        'sli': sli,
        'entropy_reduction': entropy_reduction,
        'ttr_reduction': ttr_reduction,
        'embedding_distance': embedding_distance,
        'original_entropy': original_entropy,
        'back_translation_entropy': back_translation_entropy,
        'original_ttr': original_ttr,
        'back_translation_ttr': back_translation_ttr
    }

# Main function
def main():
    """Main function to calculate SLI for dataset"""
    parser = argparse.ArgumentParser(description='Calculate Semantic Leakage Index (SLI)')
    parser.add_argument('--input', type=str, required=True, help='Input Excel file with translations')
    parser.add_argument('--output', type=str, required=True, help='Output file for SLI results')
    parser.add_argument('--dict', type=str, default='dictionary/taiwanese_custom_dictionary.txt', 
                        help='Custom dictionary for Taiwanese segmentation')
    parser.add_argument('--model', type=str, default='paraphrase-multilingual-MiniLM-L12-v2',
                        help='Sentence transformer model to use')
    parser.add_argument('--visualize', action='store_true', help='Generate visualizations')
    
    args = parser.parse_args()
    
    # Load custom dictionary
    load_custom_dict(args.dict)
    
    # Load sentence transformer model
    print(f"Loading sentence transformer model: {args.model}")
    model = SentenceTransformer(args.model)
    print("Model loaded")
    
    # Load data
    print(f"Loading data from {args.input}")
    df = pd.read_excel(args.input)
    print(f"Loaded {len(df)} rows")
    
    # Calculate SLI for each row
    print("Calculating SLI...")
    results = []
    
    for idx, row in df.iterrows():
        if idx % 100 == 0:
            print(f"Processing row {idx}/{len(df)}")
        
        original = row.get('Original_Taiwanese', '')
        translation = row.get('Mandarin_Translation', '')
        back_translation = row.get('Back_Translation', '')
        
        if not original or not translation or not back_translation:
            continue
        
        sli_results = calculate_sli(original, translation, back_translation, model)
        
        results.append({
            'id': idx,
            'original': original,
            'translation': translation,
            'back_translation': back_translation,
            **sli_results
        })
    
    # Save results
    results_df = pd.DataFrame(results)
    results_df.to_csv(args.output, index=False)
    print(f"Results saved to {args.output}")
    
    # Generate visualizations if requested
    if args.visualize:
        print("Generating visualizations...")
        os.makedirs('data/figures', exist_ok=True)
        
        # SLI distribution
        plt.figure(figsize=(10, 6))
        sns.histplot(results_df['sli'], kde=True)
        plt.title('Distribution of Semantic Leakage Index (SLI)')
        plt.xlabel('SLI')
        plt.ylabel('Frequency')
        plt.savefig('data/figures/sli_distribution.png', dpi=300, bbox_inches='tight')
        
        # Correlation heatmap
        plt.figure(figsize=(10, 8))
        corr_columns = ['sli', 'entropy_reduction', 'ttr_reduction', 'embedding_distance', 
                        'original_entropy', 'back_translation_entropy', 'original_ttr', 'back_translation_ttr']
        corr_matrix = results_df[corr_columns].corr()
        sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt='.2f')
        plt.title('Correlation Matrix of SLI Components')
        plt.savefig('data/figures/correlation_heatmap.png', dpi=300, bbox_inches='tight')
        
        # Scatter plot of entropy reduction vs embedding distance
        plt.figure(figsize=(10, 6))
        sns.scatterplot(x='entropy_reduction', y='embedding_distance', data=results_df, alpha=0.5)
        plt.title('Entropy Reduction vs Embedding Distance')
        plt.xlabel('Entropy Reduction')
        plt.ylabel('Embedding Distance')
        plt.savefig('data/figures/entropy_vs_distance.png', dpi=300, bbox_inches='tight')
        
        print("Visualizations saved to data/figures/")
    
    print("Done!")

if __name__ == "__main__":
    main()
